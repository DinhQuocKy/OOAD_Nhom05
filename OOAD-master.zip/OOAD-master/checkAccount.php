<?php  
	if(isset($_SESSION['ID'])){
		echo '<li><a href="information.php"><i class="fa fa-user"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Tài khoản của tôi</font></font></a></li>';
	}



?>