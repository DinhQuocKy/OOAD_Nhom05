<?php 
	session_start();
	$_SESSION['ID']=NULL;
?>